let email = prompt ("Dejanos tu correo y enterate de todas las novedades")

localStorage.setItem('correo',email)
console.log(console.log(localStorage))